/*************************************************************************
 * Name: Prashant Singh
 * Email: prashantfromindia@gmail.com
 *
 * Compilation:  javac Fast.java
 * Execution:	 java Fast rs1423.txt	
 * Dependencies: Point.java,StdDraw.java
 *
 * Description: This program finds collinear points among a given set of N points
 * and print them on screen.Its worst case running time is O(N^2logN).
 *
 *************************************************************************/
import java.util.Arrays;

public class Fast {
	private Point[] points;
	private Point[] pointsHelper;
	private Point[] chosenPoints = new Point[4];
	private int pointCount;

	public static void main(String[] args) {
		Fast f = new Fast();

		// rescale coordinates and turn on animation mode
		StdDraw.setXscale(0, 32768);
		StdDraw.setYscale(0, 32768);
		StdDraw.show(0);
		StdDraw.setPenRadius(0.01); // make the points a bit larger

		f.init(args[0]);			//initialize points[] array with points 
		f.start();		

		StdDraw.show(0); 			// display all points on screen
	}

	/*
	 * Reads all the points from given text file and initialize the points[].
	 */
	private void init(String fileName) {
		In in = new In(fileName); 		// read x,y from file
		pointCount = in.readInt(); 		// total points
		points = new Point[pointCount]; // stores all points
		pointsHelper = new Point[pointCount];
		for (int i = 0; i < points.length; i++) {
			int x = in.readInt();
			int y = in.readInt();
			points[i] = new Point(x, y);
			pointsHelper[i] = new Point(x, y);
		} 			
	}
	
	/*
	 * Start finding collinear points to each point in points[].*/
	private void start() {
		for (int i = 0; i < points.length; i++) {
			Point refPoint = points[i]; 						//find points collinear to each point 
			Arrays.sort(pointsHelper, refPoint.SLOPE_ORDER); 	//sort pointshelper based on slope with points[i] 

			// find points collinear to points[i]
			collinearToRefPoint(refPoint, pointsHelper);
		}
	}
	
	/*
	 * Finds and print points collinear to refPoint.*/
	private void collinearToRefPoint(Point refPoint, Point[] pointsHelper2) {
		chosenPoints[0] = refPoint;
		for (int i = 0; i+2 < pointsHelper2.length; i++) {
			chosenPoints[1] = pointsHelper2[i];		//select 3 adjacent points to check their slope
			chosenPoints[2] = pointsHelper2[i + 1];
			chosenPoints[3] = pointsHelper2[i + 2];
			if (isSlopeEqual(chosenPoints)) {
				Insertion.sort(chosenPoints);
				chosenPoints[0].drawTo(chosenPoints[3]);			//draw line segment
				i += 2;								//skip to next 3 points
			}
		}
	}

	/*
	 * @return true if slope of 4 points are equal.
	 */
	private boolean isSlopeEqual(Point[] chosenPoints) {
		double s1 = chosenPoints[0].slopeTo(chosenPoints[1]);
		double s2 = chosenPoints[0].slopeTo(chosenPoints[2]);
		double s3 = chosenPoints[0].slopeTo(chosenPoints[3]);

		if (s1 == s2 && s1 == s3)
			return true;
		return false;
	}
}
